git add .
git commit -m "Whatever"
git push

//for fetching the files
git pull

// Extensions
HTML (Optional)
live server (Compulsory)
code runner (Compulsory)
